make
wce_graph is the name of the executable
